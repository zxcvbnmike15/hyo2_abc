Version 2019v2

Unzip the Caris support files into the C:\CARIS directory. This should create a new folder named
C:\CARIS\CARIS_Support_Files_2019v2 that contains the support files and folders.

The batch file is named CARIS_Support_Files_2019v2.bat. Retain the default file paths and registry entries in the batch
file or reconfigure as desired. Execute the batch file logged in as administrator with all other users logged off the system.

The batch file (CARIS_Support_Files_2019v2.bat) will copy Version 2019v2 of the NOAA CARIS support files from the
C:\CARIS\CARIS_Support_Files_2019v2 folder to the correct CARIS folders on your machine. The process will only work if
you have the support files stored in a C:\CARIS\CARIS_Support_Files_2019v2 folder.

The support files should be copied as below:

Notebook 3.1:
<System_Files> ----------------------------->C-CARIS-Notebook-31-System
<Profiles_Pools_ProductInfo> --------------->C-CARIS-Notebook-31-System-S57Config-System
<Symbolization>----------------------------->C-CARIS-Notebook-31-System-S57Config-Symbolization-Lookup

Bathy DataBASE 4.1:
<System_Files> ----------------------------->C-Program Files-CARIS-BDB-4.1-System
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BDB-4.1-System-S57Config-System
<ProductInfo> ------------------------------>C-Program Files-CARIS-BDB-4.1-System-S57Config-System
<Symbolization>----------------------------->C-Program Files-CARIS-BDB-4.1-System-S57Config-Symbolization-Lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BDB-4.1-system-RuleFiles

BASE Editor 4.2:
<System_Files> ----------------------------->C-Program Files-CARIS-BASE Editor-4.2-system
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BASE Editor-4.2-system-S57Config-system
<ProductInfo> ------------------------------>C-Program Files-CARIS-BASE Editor-4.2-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-BASE Editor-4.2-system-S57Config-symbolization-lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BASE Editor-4.2-modules-BASE Editor-support-Rules

BASE Editor 4.3:
<System_Files> ----------------------------->C-Program Files-CARIS-BASE Editor-4.3-system
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BASE Editor-4.3-system-S57Config-system
<ProductInfo> ------------------------------>C-Program Files-CARIS-BASE Editor-4.3-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-BASE Editor-4.3-system-S57Config-symbolization-lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BASE Editor-4.3-modules-Basic Charting Tools-support-Rules

BASE Editor 4.4:
<System_Files> ----------------------------->C-Program Files-CARIS-BASE Editor-4.4-system
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BASE Editor-4.4-system-S57Config-system
<ProductInfo> ------------------------------>C-Program Files-CARIS-BASE Editor-4.4-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-BASE Editor-4.4-system-S57Config-symbolization-lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BASE Editor-4.4-modules-Basic Charting Tools-support-Rules

BASE Editor 5.1:
<System_Files> ----------------------------->C-Program Files-CARIS-BASE Editor-5.1-system
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BASE Editor-5.1-system-S57Config-system
<ProductInfo> ------------------------------>C-Program Files-CARIS-BASE Editor-5.1-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-BASE Editor-5.1-system-S57Config-symbolization-lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BASE Editor-5.1-modules-Basic Charting Tools-support-Rules

BASE Editor 5.2:
<System_Files> ----------------------------->C-Program Files-CARIS-BASE Editor-5.2-system
<Profiles_Pools> --------------------------->C-Program Files-CARIS-BASE Editor-5.2-system-S57Config-system
<ProductInfo> ------------------------------>C-Program Files-CARIS-BASE Editor-5.2-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-BASE Editor-5.2-system-S57Config-symbolization-lookup
<Rule_Files>-------------------------------->C-Program Files-CARIS-BASE Editor-5.2-modules-Basic Charting Tools-support-Rules

Plot Composer 5.3:
<System_Files> ----------------------------->C-Program Files-CARIS-PlotComposer-5.3-System
<Profiles_Pools_ProductInfo> --------------->C-Program Files-CARIS-PlotComposer-5.3-System-S57Config-System
<Symbolization>----------------------------->C-Program Files-CARIS-PlotComposer-5.3-System-S57Config-Symbolization-Lookup
<PCEConfig>--------------------------------->C-Program Files-CARIS-PlotComposer-5.3-System-PCEConfig
<Templates>--------------------------------->C-Program Files-CARIS-PlotComposer-5.3-System-Templates_53

Easyview 4.0:
<System_Files> ----------------------------->C-Program Files-CARIS-EasyView-4.0-System
<Profiles_Pools_ProductInfo>---------------->C-Program Files-CARIS-EasyView-4.0-System-S57Config-System
<Symbolization>----------------------------->C-Program Files-CARIS-EasyView-4.0-System-S57Config-Symbolization-Lookup

HIPS & SIPS 7.1
<System_Files> ----------------------------->C-CARIS-HIPS(x64)-71-System
<Profiles_Pools>---------------------------->C-CARIS-HIPS(x64)-71-System-S57Config-System
<ProductInfo>------------------------------->C-CARIS-HIPS(x64)-71-System-S57Config-System
<Symbolization>----------------------------->C-CARIS-HIPS(x64)-71-System-S57Config-Symbolization-Lookup

HIPS & SIPS 9.1
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS-9.1-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS-9.1-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS-9.1-System-S57Config-System
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS-9.1-System-S57Config-Symbolization-Lookup

HIPS & SIPS 10.2
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.2-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS and SIPS-10.2-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS and SIPS-10.2-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.2-System-S57Config-Symbolization-Lookup

HIPS & SIPS 10.3
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.3-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS and SIPS-10.3-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS and SIPS-10.3-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.3-System-S57Config-Symbolization-Lookup

HIPS & SIPS 10.4
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.4-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS and SIPS-10.4-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS and SIPS-10.4-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS and SIPS-10.4-System-S57Config-Symbolization-Lookup

HIPS & SIPS 11.1
<System_Files> ----------------------------->C-Program Files-CARIS-HIPS and SIPS-11.1-System
<Profiles_Pools>---------------------------->C-Program Files-CARIS-HIPS and SIPS-11.1-System-S57Config-System
<ProductInfo>------------------------------->C-Program Files-CARIS-HIPS and SIPS-11.1-modules-Feature Editing-support-ProductInfoFiles
<Symbolization>----------------------------->C-Program Files-CARIS-HIPS and SIPS-11.1-System-S57Config-Symbolization-Lookup

S57 Composer
<System_Files> ----------------------------->C-CARIS-S-57 Composer-30-System
<Profiles_Pools>---------------------------->C-CARIS-S-57 Composer-30-System-S57Config-System
<ProductInfo>------------------------------->C-CARIS-S-57 Composer-30-System-ProductInfoFiles
<Symbolization>----------------------------->C-CARIS-S-57 Composer-30-System-S57Config-Symbolization-Lookup

      - File Versions -

atr_lut.txt			= Version 2019v2
obj_lut.txt			= Version 2019v2
NOAA_cataloguecontrol.xml	= Version 2019v2
NOAA Profile Version 2019.xml	= Version 2019v2
NOAAunifiedPool.xml		= Version 2019v2
s57productinfo_NOAA.xml		= Version 2019v2
psymrefs.dic			= Version 2019v2
psymreft.dic			= Version 2019v2
HIPS2NOAAHOB.xml        	= Version 2019v2

IH_BorderStyles.bsd
NOAA_Plot_Template_ARCH-D_Landscape.plt
NOAA_Plot_Template_ARCH-D_Portrait.plt